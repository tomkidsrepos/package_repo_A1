# LWJGL 2 for iOS 6

Minecraft: Java Edition up to 1.12 draws with LWJGL 2 and desktop OpenGL. On the iPad, LWJGL gets an iOS
backend, and [gl4es](https://github.com/ptitSeb/gl4es) turns the desktop OpenGL into OpenGL ES 2.0.

- `java/`: the iOS backend. Kostka's Java reports `os.name` "iPhone OS X", which LWJGL (patched by `build.sh`)
  takes for its Mac OS X platform; these files replace its Mac OS X classes under the same names. The window is a UIKit view on an EAGL layer, the context an EAGL
  (OpenGL ES 2.0) context, touches are the mouse, and on-screen keys and the iOS keyboard are the keyboard.
  Nothing of AWT or Cocoa is used. A resizable window takes the whole screen, and the game hears it was resized;
  the clock (`Sys.getTime`) goes on by 0.9 s when a thread's frames keep taking over a second (Minecraft 1.3 to
  1.11 stands still after such frames: a post-processing shader too much for the iPad 2).
- `native/`: the backend's JNI side (`ios_display.m`, `ios_context.m`), gl4es on EAGL (`ios_gl4es.c`: the
  game's framebuffer 0 is the window's framebuffer object), LWJGL's OpenGL functions from gl4es
  (`ios_extgl.c`; `ios_glsl.c` takes GLSL 1.20's initial values of uniforms out of shaders, which OpenGL ES does not
  take, and sets them once the program is linked; caps fragment shader loops bound by a uniform at 8 steps, 3 when
  nested; and compiles a shader that took a whole number for a float once more with floats) and OpenAL from the
  system framework (`ios_al.c`).
- `awt/`: Kostka's AWT for Classic to 1.5.2 (launchwrapper's frame, applet and canvas): windows that exist without
  being drawn, each over the whole screen.
- `test/GLTest.java`: the first test: a turning triangle, the mouse under the finger, the keys.
- `build.sh`: fetches LWJGL 2 (its last sources, 2.9.4) and gl4es at fixed commits, runs LWJGL's generator,
  builds the jars, and cross-compiles gl4es and LWJGL's natives into one `liblwjgl.dylib` for armv7. Its changes to
  gl4es: no thread-local storage (iOS 6 has none), functions for two symbol aliases (Darwin has none), and display
  lists by name only for large ranges - `glGenLists` of more than 65536 names reserves them, as desktop drivers do,
  instead of making an entry each (Minecraft's 1.7 snapshots ask for 14 million and the memory ran out). LWJGL itself
  takes the name "iPhone OS X" for its Mac OS X platform.
  The GitHub workflow `lwjgl.yml` runs it; the app takes its result (`Resources/lwjgl`).

## Licenses

- LWJGL: BSD 3-clause, Copyright (c) 2002-2008 LWJGL Project. The files in `java/` and `native/` are under
  the same license (the replaced classes keep LWJGL's notice).
- gl4es: MIT, Copyright (c) 2016-2018 Sebastien Chevalier, (c) 2013-2016 Ryan Hileman.

The build puts both license texts next to the library (`licenses/`).
